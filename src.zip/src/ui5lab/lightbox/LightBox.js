/*!
 * ${copyright}
 */

// Provides control ui5lab.lightbox.LightBox
sap.ui.define(['jquery.sap.global', './library', 'sap/ui/core/Control'], function(
    jQuery,
    library,
    Control
) {
    'use strict';

    /**
     * Constructor for a new ui5lab.lightbox.LightBox control.
     *
     * @param {string} [sId] id for the new control, generated automatically if no id is given
     * @param {object} [mSettings] initial settings for the new control
     *
     * @class
     *
     * @extends sap.ui.core.Control
     *
     * @public
     * @alias ui5lab.lightbox.LightBox
     */
    var oControl = Control.extend(
        'ui5lab.lightbox.LightBox',
        /** @lends ui5lab.lightbox.LightBox.prototype */

        {
            /**
             * Control API
             */
            metadata: {
                library: 'ui5lab.lightbox',
                properties: {
                    text: {
                        type: 'string',
                        defaultValue: 'Hello, UI5Lab!'
                    },
                    images: {
                        type: 'object[]',
                        defaultValue: []
                    }
                }
            },

            /**
             * Lifecycle hook to initialize the control
             */
            init: function() {
                // nothing yet
            }
        }
    );

    return oControl;
});
